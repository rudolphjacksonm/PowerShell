﻿Function Disable-UserAccount {
    [cmdletbinding()]
    Param
    (
        # Name of User Account
	    [Parameter(Mandatory=$True,
                   ValuefromPipelinebyPropertyName=$True,
			       Position=0)]  
		$UserName
    )

    try {
	     $UserInstance = Get-ADuser $UserName -ErrorAction stop 

        # Logging
        $global:LogStream += "$(Get-Date), user exists, $_"
	 
    }
    catch {
	    $global:LogStream += "$(Get-Date), Cannot find user $UserName in AD, $_"
	    $global:LogStream
	    exit
	
    }

    # Verify SamAccountName matches Name parameter
	if ($UserInstance.samaccountname -eq $UserName) {
		
        if ($UserInstance.Enabled -eq $True){
            Disable-ADAccount $UserInstance

            # Logging
	        $global:LogStream += "$(Get-Date), $UserName disabled, $_"
        
        }
        else{
            $global:LogStream += "$(Get-Date), $UserName already disabled, $_"
            
        }
	}
}