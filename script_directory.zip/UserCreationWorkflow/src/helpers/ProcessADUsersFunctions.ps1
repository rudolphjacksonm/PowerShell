﻿
. .\helpers\New-SWRandomPassword.ps1

function Verify-UserAccountExist {
    [CmdletBinding()]
    Param
    (
        # Username
        [Parameter(Mandatory=$true,
                   Position=0)]
        $Username,

        # IT OU
        [Parameter(Mandatory=$true,
                   Position=1)]
        $orgUnit
    )

    # Verify is account exists
    try{
        $adUser = Get-ADUser -Filter {sAMAccountName -eq $Username} -SearchBase $orgUnit -ErrorAction Stop
    }
    catch{
        $global:LogStream += "$(Get-Date), $Username, Exists, $_"
    }

    # Logging
        $global:LogStream += "$(Get-Date), $Username, Exists, $([bool]$adUser)"

    # Output
    [bool]$adUser
}


function New-UserAccount {
    [CmdletBinding()]
    Param
    (
        # Username
        [Parameter(Mandatory=$true,
                   Position=0)]
        $Username,

        # FullName
        [Parameter(Mandatory=$true,
                   Position=1)]
        $FullName,

        # Email Address
        [Parameter(Mandatory=$true,
                   Position=2)]
        $EmailAdress,

        # IT OU
        [Parameter(Mandatory=$true,
                   Position=3)]
        $orgUnit
    )

    # Create missing AD Account
    try{
        $props = @{
            'Path' = $orgUnit
            'SamAccountName' = $Username
            'GivenName' = ($FullName -split ' ')[0]
            'Surname' = ($FullName -split ' ')[1]
            'AccountPassword' = $(ConvertTo-SecureString $(New-SWRandomPassword -MinPasswordLength '10' -MaxPasswordLength '14') -AsPlainText -Force)
            'Enabled' = $False
            'DisplayName' = $FullName
            'Name' = $FullName
            'UserPrincipalName' = $Username + ($orgUnit -replace 'DC=(.*),DC=(.*)', '@$1.$2' -replace '.*,','')
            'PasswordNeverExpires' = $True
            'EmailAddress' = $EmailAdress
        }

        New-ADUser @props -ErrorAction Stop
    }
    catch{
        $global:LogStream += "$(Get-Date), $Username, Create Account, $_"
    }
    
    $S7UserExists = Verify-UserAccountExist -Username $Username -orgUnit $orgUnit

    if($S7UserExists){
        # Logging
        $global:LogStream += "$(Get-Date), $Username, Create Account, True."

    }
    else{
        # Logging
        $global:LogStream += "$(Get-Date), $Username, Create Account, Could not verify account creation."
    }
}

