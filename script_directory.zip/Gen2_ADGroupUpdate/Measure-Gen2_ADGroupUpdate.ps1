param(
    # Date
    [Parameter(Mandatory=$true,
                Position=0)]
    [datetime]$Date,

    # FullName
    [Parameter(Mandatory=$false,
                Position=1)]
    $ProjectPath = 'C:\Users\jmorris\Documents\WindowsPowershell\Scripts\Gen2_ADGroupUpdate\reports'
)

# Import Measured Automation Module
Import-Module C:\Users\jmorris\Documents\WindowsPowershell\Scripts\Gen2_ADGroupUpdate\MeasureAutomationModule.ps1


# Reset AutomationTable
New-AutomationTable


# Collect Automation Reports
$automationReports = Get-AutomationReports -ReportPath $ProjectPath -Date $Date


### EDIT THIS SECTION
# Use this section to filter down the reports you process

$targetautomationReports = $automationReports | Where-Object {$_.fullname -like '*syncHistory*'}


### EDIT THIS SECTION
# Use this sectipn to build the Automation Table
# IE: New-AutomationTask -TaskName ProcessPasswordExpirationAllAccounts -SecondsPerItem '90'
#

New-AutomationTask -TaskName 'AccountsChecked' -SecondsPerItem '15'
New-AutomationTask -TaskName 'ADGroupAddition' -SecondsPerItem '30'



$commandsRun_count = [int]0
$ticketCreatedObject = @()

if(($targetautomationReports | Measure-Object | Select-Object -ExpandProperty Count) -gt 0 -and ($targetautomationReports -ne $null)){
    
    $targetautomationReports |  ForEach-Object { 
        $reportFullName =  $_.FullName
        $reportDate = $_.ReportDate
        
        $report = Import-Csv -Path $reportFullName

        ### EDIT THIS SECTION
        # Use this section to add items to your automation task
        # IE:  $adusers = Get-ADUser -filter *
        #      Set-AutomationTask -TaskName ProcessPasswordExpirationAllAccounts -Items $adusers
        #
       
	    #Calculate total number of accounts checked
		$accountsChecked = ($report | Select-Object -Property Username)
		$accountsChecked_count += $accountsChecked | Measure-Object | Select-Object -ExpandProperty Count
		
		#Calculate total number of commands run to change accounts
	    $commandsRun = ($report | Where-Object {$_.action -eq 'Added'})
		$commandsRun_count += $commandsRun | Measure-Object | Select-Object -ExpandProperty Count
	   
    }
	
	# Add Commands Ran Value
	Set-AutomationTask -TaskName 'AccountsChecked' -Items $accountsChecked_count
	Set-AutomationTask -TaskName 'ADGroupAddition' -Items $commandsRun_count

    # Returns the measured automation object
    Get-AutomationTable

}
