﻿# Initialize the Automation Table


# Measured Automation Path
$ScriptPath = $MyInvocation.MyCommand.Path
$global:MeasuredAutomationModulePath = Split-Path -Parent $ScriptPath



### FOCUS: Used to keep track of tasks and time savings. 
# Examples of implementation within measuredScriptTemplate.ps1

# Create a new Automation Table
function New-AutomationTable{
    
    $global:automationTable = @()
 
}

# Return the full Table
function Get-AutomationTable {
    [CmdletBinding()]
    [OutputType([PSObject])]
    
    param(
    )

    $global:automationTable
}

# Return a list of tasks from the automation table
function Get-AutomationTasks{

    Get-AutomationTable | Select-Object -ExpandProperty TaskName

}

# Add a new task into the automation table
function New-AutomationTask{
    [CmdletBinding()]
    Param
    (
        # The name of the Task that you are automating (IE: 'Getting all AD users.', 'Changing primary SMTP for active accounts.')
        [Parameter(Mandatory=$true,
                   Position=0)]
        [string]$TaskName,

        # The avg time it takes (seconds) to do one instance of this Task.
        [Parameter(Mandatory=$true,
                   Position=1)]
        [int]$SecondsPerItem

    )

    $props = @{
        'TaskName' = $TaskName
        'Items' = $null
        'SecondsPerItem' = $SecondsPerItem
        'SecondsTotal' = $null
    }

    $global:automationTable += New-Object -TypeName PSObject -Property $props
}

# Specify a task that already exists, set the time in seconds per instance of a task. 
# Seconds Total column is auto generated.
function Set-AutomationTask {
    [CmdletBinding()]
    
    Param
    (
        # 
        [Parameter(Mandatory=$false,
                   ValueFromPipelineByPropertyName=$true,
                   Position=0)]
                    
                    [Validatescript({
	                    if ($(Get-AutomationTasks) -contains $_) { $true }
	                    else { throw "$_ is not a TaskName found in the `$global:AutomationTable. 

    Possible TaskName's are: $($(Get-AutomationTasks) -join ', ')

                        "}
	                })]

        [string]$TaskName,

        # 
        [Parameter(Mandatory=$false,
                    ValueFromPipelineByPropertyName=$true,
                    Position=1)]
        [int]$Items,

        # 
        [Parameter(Mandatory=$false,
                    ValueFromPipelineByPropertyName=$true,
                    Position=2)]
        [int]$SecondsPerItem,

        # 
        [Parameter(Mandatory=$false,
                    ValueFromPipelineByPropertyName=$true,
                    Position=3)]
        [int]$SecondsTotal
    )

    #
    function SetAutomationTaskProperties {
        [CmdletBinding()]
        param(
        #
        [Parameter(Mandatory=$false,
                    ValueFromPipelineByPropertyName=$true,
                    Position=0)]
        [string]$TaskName,
        
        # 
        [Parameter(Mandatory=$false,
                    ValueFromPipelineByPropertyName=$true,
                    Position=1)]
        [int]$Items,

        # 
        [Parameter(Mandatory=$false,
                    ValueFromPipelineByPropertyName=$true,
                    Position=2)]
        [int]$SecondsPerItem,

        # 
        [Parameter(Mandatory=$false,
                    ValueFromPipelineByPropertyName=$true,
                    Position=3)]
        [int]$SecondsTotal
        )


        if($SecondsTotal -eq '0'){
            $SecondsTotal = ($Items * $SecondsPerItem)
        }

        $props = @{
            'TaskName' = $TaskName
            'Items' = $Items
            'SecondsPerItem' = $SecondsPerItem
            'SecondsTotal' = $SecondsTotal
        }


        New-Object -TypeName PSObject -Property $props

    }

    $AutomationTable = Get-AutomationTable 
    $AutomationTask = $AutomationTable | Where-Object {$_.TaskName -eq $TaskName} -ErrorAction Stop

    $SetAutomationTask = $AutomationTask | SetAutomationTaskProperties -Items $Items

    $global:automationTable = @()
    foreach($entity in $AutomationTable){
        if($entity -ne $AutomationTask){
            $global:automationTable += $entity
        }
    }

    $global:automationTable += $SetAutomationTask
    
}

### FOCUS: To be used within the Measured Projects template
## Get-AutomationReports
# Function is responsible for normalizing all reports in the folder
# And then, selecting the valid ones based on date time provided.
# The default behavior is to handle reports from today.
function Get-AutomationReports{
    [CmdletBinding()]
    param(
        # Cached file path (CSV Location)
        [Parameter(Mandatory=$true,
                   Position=0)]
        [string]$ReportPath,

        # Search Range - Start Date
        [Parameter(Mandatory=$false,
                   Position=1)]
        [datetime]$StartDate,

        # Search Range - End Date
        [Parameter(Mandatory=$false,
                   Position=2)]
        [datetime]$EndDate,

        # Search Date,
        [Parameter(Mandatory=$false,
                   Position=3)]
        [datetime]$Date = (Get-Date)
    )


    # Regex for stripping automation .csv naming scheme into date/time sortable object
    ### Format: 1618778396___04_24_2016__UnhandledUsersAudit.csv
    ### Exampl: [random  ]___[msg date]__[original file name   ]
    function NormalizeAutomationReports {
        [cmdletbinding()]
        param(
            # Cached file path (CSV Location)
            [Parameter(Mandatory=$true,
                       ValueFromPipelineByPropertyName = $true,
                       Position=0)]
            [string]$Name,

            [Parameter(Mandatory=$true,
                       ValueFromPipelineByPropertyName = $true,
                       Position=1)]
            [string]$FullName
        )

        process{

            $props = @{
                'ReportDate' = (Get-Date (($Name -replace '.*___(.*)__.*','$1') -replace '_','/')).Date
                'FullName' = $FullName
            }

            New-Object -TypeName PSObject -Property $props
    
        }
    }

    # Normalize automation reports from 
    $automationReports = Get-ChildItem -Path $ReportPath | NormalizeAutomationReports
    
    if($StartDate -and $EndDate){
        
        $targetautomationReports = $automationReports | Where-Object {$_.ReportDate -ge $StartDate.Date -and $_.ReportDate -le $EndDate.Date}

    }
    else{
        $targetautomationReports = $automationReports | Where-Object {$_.ReportDate -eq $Date.Date}

    }

    $targetautomationReports
}