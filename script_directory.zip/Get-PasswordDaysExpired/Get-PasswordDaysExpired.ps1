﻿<#




#>

#Import AD module in to Powershell
Import-Module ActiveDirectory

#Get-ADUser -filter {Enabled -eq $True -and PasswordNeverExpires -eq $False} –Properties "SamAccountName","msDS-UserPasswordExpiryTimeComputed" | Select-Object -Property "SamAccountName", @{Name="Password Expiry Date"; Expression={[datetime]::FromFileTime($_."msDS-UserPasswordExpiryTimeComputed")}}

function Get-PasswordDaysExpired {
    [CmdletBinding()]
    param(
    [parameter(
    Mandatory = $true,
    ValuefromPipelinebypropertyname = $true)]
    $SamAccountName,

    [parameter(
    Mandatory = $true,
    ValuefromPipelinebypropertyname = $true)]
    ${msds-userpasswordexpirytimecomputed}
   
    )

    begin{
    }
    process{
    
        $ExpiryDate = [datetime]::FromFileTime(${msds-userpasswordexpirytimecomputed})
        $DaysSincePasswordExpired = (Get-Date).DayofYear - ($ExpiryDate).DayOfYear
   
        if ($DaysSincePasswordExpired -ge 0) {

            $UserAccountStatus = New-Object -TypeName PSObject -Property @{AccountName=$SamAccountName; DaysExpired=$DaysSincePasswordExpired}
            }

        $UserAccountStatus
    }
    end{
    }
}