﻿#source directory
$sourcedir = Get-ChildItem src

# flat files at root
$sourcedir | Where-Object {$_.psiscontainer -eq $false} | Select -exp FullName | Copy-Item -Destination stable -Force

# subfolders, resursively copied
$sourcedir | Where-Object {$_.psiscontainer -eq $true -and $_.Name -notlike '*_amp*'} | Select -exp FullName | Copy-Item -Recurse -Destination stable -Force