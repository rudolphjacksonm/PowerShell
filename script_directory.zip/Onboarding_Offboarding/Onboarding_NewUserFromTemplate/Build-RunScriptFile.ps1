﻿[cmdletbinding()]
param(
    # MainScriptLocation
    [Parameter(Mandatory=$true,
                ValueFromPipelineByPropertyName=$true,
                Position=0)]
    $MainScriptLocation
)


function Get-ScriptParameters {
    param(
        [Parameter(Mandatory=$true,
                   ValueFromPipelineByPropertyName=$true,
                   Position=0)]
        $FullName
    )

    $paramEnd = Get-Content $FullName | Select-String '^[)]$' | Select-Object -ExpandProperty LineNumber

    $parameters = (Get-Content $FullName)[0..$paramEnd] -match '(^(?!.*=\$)).*[$]' -replace '[[].*[]]','' -replace ',',''

    $parameters
}

function Get-ScriptBody {
    param(
        [Parameter(Mandatory=$true,
                   ValueFromPipelineByPropertyName=$true,
                   Position=0)]
        $FullName
    )

    $paramEnd = Get-Content $FullName | Select-String '^[)]$' | Select-Object -ExpandProperty LineNumber

    $scriptEnd = Get-Content $FullName | Measure-Object | Select-Object -ExpandProperty Count

    $scriptBody = (Get-Content $FullName)[$paramEnd..$scriptEnd] 

  

    $script = @()
    $scriptBody |  ForEach-Object { 
        if($_ -notmatch '[.]\s[.]'){
            $script += $_

        }
        else{
            $nestedScript = Get-Content ($_ -replace '[.] [.]\\','stable\\').trimstart()

            $nestedScript |  ForEach-Object { 
                if($_ -notmatch '[.]\s[.]'){
                    $script += $_

                }
                else{
                    $nestedScript = Get-Content ($_ -replace '[.] [.]\\','stable\\').trimstart()

                    $script += $nestedScript

                }
            }
        }
    }

    $script
}


# Get Scripts from this directory
$mainScriptFile = Get-Item $MainScriptLocation

$parameters = Get-ScriptParameters -FullName $mainScriptFile.Fullname

$scriptBody = Get-ScriptBody -FullName $mainScriptFile.Fullname

$runScriptFile = $parameters + ' ' + $scriptBody

# Output the final script
$runScriptOutput = "$pwd\_amp\$($mainScriptFile.Name)" -replace '(.*).ps1','$1_runScript.ps1'
$runScriptFile | Out-File $runScriptOutput
