﻿
. .\helpers\New-SWRandomPassword.ps1

function Verify-UserAccountExist {
    [CmdletBinding()]
    Param
    (
        # Username
        [Parameter(Mandatory=$true,
                   Position=0)]
        $Username,

        # IT OU
        [Parameter(Mandatory=$true,
                   Position=1)]
        $orgUnit
    )

    # Verify is account exists
    try{
        $adUser = Get-ADUser -Filter {sAMAccountName -eq $Username} -SearchBase $orgUnit -ErrorAction Stop
    }
    catch{
        $global:LogStream += "$(Get-Date), $Username, Exists, $_"
    }

    # Logging
        $global:LogStream += "$(Get-Date), $Username, Exists, $([bool]$adUser)"

    # Output
    [bool]$adUser
}


function Copy-ADTemplateUser {
    [CmdletBinding()]
    Param
    (
        # Username
        [Parameter(Mandatory=$true,
				   ValueFromPipelineByPropertyName=$true,
                   Position=0)]
        $Username,

        # FullName
        [Parameter(Mandatory=$true,
				   ValueFromPipelineByPropertyName=$true,
                   Position=1)]
        $FullName,

        # Email Address
        [Parameter(Mandatory=$true,
				   ValueFromPipelineByPropertyName=$true,
                   Position=2)]
        $EmailAddress,
		
		# Autotask Account Name
		[Parameter(Mandatory=$true,
					ValueFromPipelineByPropertyName=$true,
					Position=3)]
		$AutotaskAccountName
    )
	
	# Format Autotask Account Name
	$FormattedAutotaskAccountName = $AutotaskAccountName -replace ',','\,'
	
	# Gather template accounts in domain and filter by Autotask Account Name
	$TemplateAccounts = Get-ADUser -filter * | where-object {$_.samaccountname -like "*template*"}
	$TemplateInstance = $TemplateAccounts | where-object {$_.distinguishedname -like "*$FormattedAutotaskAccountName*"} | Get-ADUser -properties *
    
    if ($TemplateInstance) {
        # Logging
        $global:LogStream += "$(Get-Date), located template account for $AutotaskAccountName"

        # Stripping template CN from distinguished name so new account is placed in correct OU
        $OU = $TemplateInstance | Select-Object -ExpandProperty distinguishedname
        $TargetOU = ($OU -replace '^.*?,' , '')
    
        # Removing "template" from home directory path 
        
        try {
            $HomeDirectory = $TemplateInstance | Select-Object -ExpandProperty HomeDirectory

            if ($HomeDirectory -eq $null) {
                $TargetHomeDirectory = $null

            }
            else {
                $TargetHomeDirectory = $HomeDirectory -replace 'template',"$Username"

            }
        }
		catch {
			$TargetHomeDirectory = $Null
		
		}
		
		# Detect value of scriptpath, if whitespace set to null
		try {
			$ScriptPath = $TemplateInstance | Select-Object -ExpandProperty ScriptPath

		}
		catch{
			$ScriptPath = $null
		
		}
        # Detect value of homedrive (drive letter), if whitespace set to null
        try {
			$HomeDrive = $TemplateInstance | Select-Object -ExpandProperty HomeDrive

		}
		catch{
			$HomeDrive = $null
		
		}
		
        try{
            $props = @{
                'GivenName' = ($FullName -split ' ')[0]
                'Surname' = ($FullName -split ' ')[1]
                'EmailAddress' = $EmailAddress
                'Name' = $FullName
                'SamAccountName' = $Username
                'HomeDrive' = $HomeDrive
                'HomeDirectory' = $TargetHomeDirectory
                'Path' = $TargetOU
			    'ScriptPath' = $ScriptPath
                'UserPrincipalName' = $Username + ($OU -replace 'DC=(.*),DC=(.*)', '@$1.$2' -replace '.*,','')
           
            }

            New-ADUser @props -ErrorAction Stop

        }
        catch{
            $global:LogStream += "$(Get-Date), $Username, Create Account from Template, $_"
        }

    }
    else{
        $global:LogStream += "$(Get-Date), there is no template account for Autotask Account Name: $AutotaskAccountName"
         
    }
	
    

    # Verifies user account was created properly and adds to log stream, that's it.
    $S7UserExists = Verify-UserAccountExist -Username $Username -orgUnit $TargetOU

    if($S7UserExists){
        # Logging
        $global:LogStream += "$(Get-Date), $Username, Create Account, True."

    }
    else{
        # Logging
        $global:LogStream += "$(Get-Date), $Username, Create Account, Could not verify account creation."
    }
}