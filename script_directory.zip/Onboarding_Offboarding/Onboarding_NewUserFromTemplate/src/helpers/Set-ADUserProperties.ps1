function Set-ADUserProperties {
	[CmdletBinding()]
    Param
    (
        # Hashtable of incoming parameters
        [hashtable]$Attributes,

        # Username
        [Parameter(Mandatory=$true,
                   ValuefromPipelinebyPropertyName=$true)]
        $Username

    )

    $NewHashTable = @{}

    $Attributes.GetEnumerator() | ForEach-Object {
        $Key = $_.key
        $Value = $_.value

        if ($Value -match "blank"){
            $Value = $null
        
        }

        $NewHashTable.add($Key,$Value)
    }

    Set-ADUser -identity $Username @NewHashTable

}

