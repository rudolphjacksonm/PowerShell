﻿function Remove-ExchangeInboxRules {
    [CmdletBinding()]
    Param
    (
		# The identity of the rule from Get-InboxRule command
        [Parameter(Mandatory=$true,
                   ValuefromPipelinebyPropertyName=$true,
                   Position=0)]
        $Identity,
		
		# Name of the rule received from pipeline
		[Parameter(Mandatory=$true,
                   ValuefromPipelinebyPropertyName=$true,
                   Position=1)]
        $RuleName
    )
	
	begin {
    }
    process {
        # Remove rules
        try {
            Remove-InboxRule -identity $Identity -Confirm:$False -Force
            
            # Logging
            $global:Logstream += "$(Get-Date), removed rule $RuleName, rule ID: $Identity"

        }
        catch {
            $global:Logstream += "$(Get-Date), could not remove rule $RuleName, $_"
        
        }
    }
    end {
    }
}