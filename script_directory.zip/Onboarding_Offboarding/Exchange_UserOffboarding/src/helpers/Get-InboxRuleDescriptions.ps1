﻿function Get-InboxRuleDescriptions {
    [CmdletBinding()]
    Param
    (
        # The name of the rule from the Get-InboxRule command
        [Parameter(Mandatory=$true,
                   ValuefromPipelinebyPropertyName=$true,
                   Position=0)]
        $Name,
		
		# Description of what the rule does; parameter Description from Get-InboxRule command
        [Parameter(Mandatory=$true,
                   ValuefromPipelinebyPropertyName=$true,
                   Position=1)]
        $Description,

		# The identity of the rule from Get-InboxRule command
        [Parameter(Mandatory=$true,
                   ValuefromPipelinebyPropertyName=$true,
                   Position=2)]
        $Identity
    )
 
   
    begin {
    }
    
    process {
        
        # Logging
        $global:LogStream += "$(Get-Date), Rule Name: $Name, Rule Description: $Description"
        
        # Output
        $props = @{
            'RuleName' = $Name
            'Description' = $Description
            'Identity' = $Identity
        }

        New-Object -TypeName PSObject -Property $props

    }
    end {
    }
}