﻿function Create-DeploymentShare {
    [cmdletbinding()]
    Param
    (
        # The name of our deployment share
        [Parameter(Mandatory=$true,
                   Position=0)]
        $ShareName
    )

    function VerifyDeploymentShare{
        param(
            $gwmisharename
        )
        
        [bool](Get-WmiObject -Class Win32_Share | Where-Object {$_.Name -eq $gwmisharename})
    }

    # Preferred deployment roots
    $rootList = "D:", "E:"

    # Focus on our preferred roots
    #$SystemDrives = Get-PSProvider -PSProvider FileSystem | Select-Object -ExpandProperty Drives | Where-Object {$_.Root -eq $rootList[0] -or $_.Root -eq $rootList[1]} | Sort-Object Name
    $SystemDrives = gwmi win32_logicaldisk | Where-Object {$_.DeviceID -eq $rootList[0] -or $_.DeviceID -eq $rootList[1]} | Where-object {$_.DriveType -eq '3'} | Sort-Object DeviceID
    

    # Does the deployment share exist?
    $deploymentShareCreated = VerifyDeploymentShare $ShareName
    
    # Cycle through our sorted list of drives and try to create share.
    $SystemDrives | ForEach-Object {
        # Break out of loop
        if($deploymentShareCreated){
            continue
        }

        $driveRoot = $_.DeviceID + '\'
        $deploymentFolder = Join-Path -Path $driveRoot -ChildPath $ShareName

        # Create Folder
        New-Item $deploymentFolder -Type Directory

        # Create Share
        $scriptblock = "net share $ShareName=$deploymentFolder /GRANT:Administrators,FULL /GRANT:MDTUser,READ"
        cmd /c $scriptblock

        # Verify if share exists
        $deploymentShareCreated = VerifyDeploymentShare $ShareName

    }
}