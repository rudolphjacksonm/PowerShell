﻿#Main Deployment Script

Set-Location 'C:\Scripts\Image Deployment'
. .\helpers\Create-DeploymentShare.ps1


#Step 1: Create MDT User
Invoke-Command -ScriptBlock {net user MDTuser S7support!! /add}


#Step 2: Create Deployment Share
Create-DeploymentShare -ShareName WIMs


#Step 3: Set NTFS/Share Permissions
#Assign NTFS and share permissions
$WIMacl = Get-Acl E:\WIMs
$WIMacl.SetAccessRuleProtection($True, $False)

#Remove Users group access
$rule = New-Object System.Security.AccessControl.FileSystemAccessRule("Users","ReadPermissions, Read, ReadAndExecute", "ContainerInherit, ObjectInherit", "None", "Allow")
$WIMacl.RemoveAccessRuleAll($rule)
Set-Acl E:\WIMs $WIMacl
$rule = $null

#Add MDTuser access
$rule = New-Object System.Security.AccessControl.FileSystemAccessRule("MDTuser","Read, ReadAndExecute", "ContainerInherit, ObjectInherit", "None", "Allow")
$WIMacl.AddAccessRule($rule)
Set-Acl E:\WIMs $WIMacl
$rule = $null
