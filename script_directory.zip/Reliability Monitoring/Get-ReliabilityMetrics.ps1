﻿function Get-ReliabilityMetrics { 
    [CmdletBinding()]
    param(
    )

    $global:LogStream = @()
    # Gathers system stability index from win32_reliabilitymetrics from the past hour.

    try {
        $Metrics = Get-WmiObject win32_reliabilitystabilitymetrics | select -First 1
        $StabilityIndex = $Metrics | select -expandproperty systemstabilityindex
        
        # Logging
        $global:LogStream += "$(Get-Date), current stability index is: $StabilityIndex"

    }
    catch{
        # Logging
        $global:LogStream += "$(Get-Date), could not query stability index."

    }
    
    $StabilityIndex
    $global:LogStream

}

Get-ReliabilityMetrics | select -first 1