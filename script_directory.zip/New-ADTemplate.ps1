﻿<# NOTES

    parameters will be passed to function when called up, similar to lasttaskresult amp
    

#>

function New-ADTemplate {
    [cmdletbinding()]
    param(
    [Parameter(
    Mandatory = $true)]
    [string]$DisplayName,
    [Parameter(
    Mandatory = $true)]
    [string]$GivenName,
    [Parameter(
    Mandatory = $true)]
    [string]$Surname,
    [Parameter(
    Mandatory = $true)]
    [string]$EmailAddress,
    [Parameter(
    Mandatory = $true)]
    [string]$HomeDirectory,
    [Parameter(
    Mandatory = $true)]
    [string]$HomeDrive,
    [Parameter(
    Mandatory = $true)]
    [string]$SamAccountName
    )

    Import-Module ActiveDirectory

    try{
        New-ADUser -DisplayName $DisplayName -EmailAddress $EmailAddress -GivenName $GivenName -Surname $Surname -HomeDirectory $HomeDirectory -HomeDrive $HomeDrive -SamAccountName $SamAccountName | Write-Output -Verbose
    }
    catch{
        $global:ErrorLog = $_
    }
}



