﻿

    [CmdletBinding()]
    param (    

    #task name
    [Parameter(Mandatory=$true,
                ValueFromPipelineByPropertyName=$true,
                Position=0)]
    $TaskName
    
    )

    Set-Location C:\Users\jmorris\Documents\WindowsPowershell\Scripts\Run-ScheduledTasks\src
    . .\helpers\Get-ScheduledTasks.ps1

    $Task = Get-ScheduledTasks -taskname balls
    $CmdRuntask = cmd /c schtasks /run /tn $TaskName

    Invoke-Command -ScriptBlock {$CmdRuntask}