﻿<# 
   Gets raw output for all scheduled tasks on local machine
#>
function Get-ScheduledTasks {
    [cmdletbinding()]

    $schedule = New-Object -ComObject Schedule.Service
    $schedule.connect("localhost")
    $tasks = $schedule.GetFolder("\").gettasks(0)
    $tasks
}

function Get-ScheduledTask {
  
    
}