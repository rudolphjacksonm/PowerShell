﻿# Modify $Roots array with your target folders
#Supply how many levels deep the script should search
#0 = Max Depth
$Roots = @{
    "C:\" = "1";
}

$LogFolder = "C:\Temp\PermissionsAudit"
$LogPrefix = "PermissionsAudit"

function Get-FormattedPermissionTable{
    [Cmdletbinding()]
    param(
        $targetfolder
    )

    Get-Acl $targetfolder | Select -ExpandProperty Access | Where-Object {
        $_.IdentityReference -notlike "*SYSTEM*" # -and 
        #$_.IdentityReference -notlike "*BUILTIN*" -and 
        #$_.IdentityReference -notlike "*CREATOR*"
    } | Sort IdentityReference | 
            Format-Table IdentityReference, 
                @{Expression={$_.FileSystemRights -replace "Synchronize","" -replace ",",""};Label="FileSystemRights";align='left'}, 
                AccessControlType,  
                IsInherited,
                PropagationFlags -AutoSize  
}

$Roots.GetEnumerator() | ForEach-Object {
    #Root Level
    $RootObject = Get-Item -Path $_.Key.ToString() -ErrorAction SilentlyContinue -ErrorVariable NoFolder

    if([bool]$NoFolder){

        "$_.Name is not a valid path"
    }
    else{

        $RootName = ($RootObject | Select -ExpandProperty Name) -replace '[:]\\','_'

        #Search Depth
        $depth = $_.Value

        if($depth -eq 0){
            $depth = "256"
        }
        $MaxDepth = $depth

        $LogFile = "$LogFolder`_$LogPrefix`_$RootName`_Depth=$MaxDepth.txt"

            "Start Depth: 1 folder(s) deep from drive letter." | Out-File $LogFile -append
            
            "Maximum Search Depth: $MaxDepth folders deep from root target." | Out-File $LogFile -append
        
            "" | Out-File $LogFile -append

            "Root: $RootObject" | Out-File $LogFile -append

            "Owner: $($RootObject.GetAccessControl() | Select -ExpandProperty Owner)" | Out-File $LogFile -append
    
            Get-FormattedPermissionTable $RootObject | Out-File $LogFile -append
        

        $RootSearch = "$($RootObject.FullName)"
        $SearchFolders = $null

        1..$depth | ForEach-Object {

            $RootSearch = $RootSearch + "\*"
            $RootSearch

            $SearchFolders = $SearchFolders + (Get-ChildItem $RootSearch | Where-Object {$_.PSisContainer -eq $true})
        }

        $SearchFolders | Select FullName | Sort FullName | ForEach-Object {
            
            $SubFolder = $_.FullName

            "" | Out-File $LogFile -append

            "Sub Folder: $SubFolder" | Out-File $LogFile -append

            "Owner: $($SubFolder | Get-Acl | Select -ExpandProperty Owner)" | Out-File $LogFile -append
    
            Get-FormattedPermissionTable $SubFolder | Out-File $LogFile -append
        }
    }
}