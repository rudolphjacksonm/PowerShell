﻿<#

#>
function Get-ScheduledTasks {
    [cmdletbinding()]

    $schedule = New-Object -ComObject Schedule.Service
    $schedule.connect("localhost")
    $tasks = $schedule.GetFolder("\").gettasks(0)

}