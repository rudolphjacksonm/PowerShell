﻿function Verify-ClientSystemRestore{
    [cmdletbinding()]
    param(
    )
    
    # Check if System Restore is Enabled
    # RPSessionInterval 1 = Enabled

    try {
        $RPSessionInterval = Get-WmiObject -Namespace 'root\default' -Class 'SystemRestoreConfig' | Select-Object -ExpandProperty RPSessionInterval -ErrorAction Stop
    
    }
    catch {
        $global:LogStream += "$(Get-Date), could not query RPSessionInterval, $_"

    }

    if ($RPSessionInterval -eq 1){

        $boolCompRestoreEnabled = $True

        # Days Since Last Restore
        #If no restore points have been made, $listRestorePoints = $null
        $listRestorePoints = Get-WmiObject -Namespace root\default -Class 'SystemRestore' | Sort-Object CreationTime -Descending | Select-Object @{n='CreationTime';e={$_.ConvertToDateTime($_.CreationTime)}}

        if ($listRestorePoints -eq $null){
            $DaysSinceLastRestoreDate = 888888
        }
        elseif(($listRestorePoints | Measure-Object | Select -expandProperty Count) -eq 1){
            $DaysSinceLastRestoreDate = ((Get-Date)-($ListRestorePoints.CreationTime)).days
        }
        else{
            $DaysSinceLastRestoreDate = ((Get-Date)-($ListRestorePoints[0].CreationTime)).days
        }
    }
    else{
        # Second check if RPSessionInterval fails

        $boolCompRestoreEnabled = $True

        # Days Since Last Restore
        #If no restore points have been made, $listRestorePoints = $null
        try {
            $listRestorePoints = Get-WmiObject -Namespace root\default -Class 'SystemRestore' | Sort-Object CreationTime -Descending | Select-Object @{n='CreationTime';e={$_.ConvertToDateTime($_.CreationTime)}} -ErrorAction Stop

        }
        catch {
            $global:LogStream += "$(Get-Date), could not enumerate restore points, $_"

        }
        

        if($listRestorePoints -eq $null) {
            $boolCompRestoreEnabled = $false

            $DaysSinceLastRestoreDate = 999999
        }
        elseif(($listRestorePoints | Measure-Object | Select -expandProperty Count) -eq 1){
            $DaysSinceLastRestoreDate = ((Get-Date)-($ListRestorePoints.CreationTime)).days
        }
        else{
            $DaysSinceLastRestoreDate = ((Get-Date)-($ListRestorePoints[0].CreationTime)).days
        }
    }

    # Output Props
    $restoreStatus = @{
        Enabled = $boolCompRestoreEnabled
        DaysSinceLastRestorePoint = $DaysSinceLastRestoreDate
        
    }

    # Output Object
    New-Object -TypeName PSObject -Property $restoreStatus
}