﻿#region Pre-Run Steps
# Init LogStream

$global:Logstream = @()


# Init ScriptRoot

$ScriptPath = $MyInvocation.MyCommand.Path
$global:ScriptRoot = Split-Path -Parent $ScriptPath
#endregion


## ---- Main Code Starts here ---- 
## . $global:ScriptRoot\helpers\somefunctionhelpers.ps1
## Import-Module Some-Module
##
##
## Main
##       Script
##
##   Main
##          Script
##
##      Main
##             Script
## 
##
##  $syncActions = MyGet-ProcessObjectsFunction
##
## ---- Main Code Ends here ----



#region Export Analysis to CSV
# Only attempt to export if we have syncActions

if($syncActions.count -gt 0){
    $date = Get-Date
    $reportDateTime = ((($date).GetDateTimeFormats())[3] -replace '/','_') + "_$($date.hour)"
    $syncActions | Export-Csv "$global:ScriptRoot\synchistory\syncHistory_$reportDateTime`.csv" -NoTypeInformation

}
#endregion


#region Wrap up/Send email if we have Sync Actions to report on

if(Test-Path "$global:ScriptRoot\synchistory\syncHistory_$reportDateTime`.csv"){
    # import smtpoptions
    . $global:ScriptRoot\helpers\SMTPOptions.ps1

    # build attachment array
    $attachmentArray = @()
    $attachmentArray += "C:\Scripts\SyncConfluenceAndNCentral\synchistory\syncHistory_$reportDateTime`.csv"


    # send email with report
    $smtpProps = @{
        'SmtpServer' = $global:smtpserver
        'To' = $global:emailalertTo
        'From' = $global:emailalertFrom
        'Subject' = $global:emailsubject
        'Attachments' = $attachmentArray
    }

    Send-MailMessage @smtpProps

}
#endregion