# Remember to edit the -SearchBase to the correct domain name.
#-------------------------------------------------------------------------------------------
 
# Import AD Module
Import-Module ActiveDirectory
 
write-Host 'Starting to update AD Attributes.......' -NoNewline -ForegroundColor Yellow
# Import CSV into variable $users
 
$users = Import-Csv -Path C:\temp\test-csv.csv
# Loop through CSV and update users if the exist in CSV file
 
foreach ($user in $users) {
#Search in specified OU and Update existing attributes
Get-ADUser -Filter "EmailAddress -eq '$($user.EmailAddress)'" -Properties * -SearchBase "DC=horizon,DC=local" |
Set-ADUser -GivenName $($user.FirstName) -surname $($user.LastName) -EmailAddress $($user.EmailAddress) -Description $($user.Description) -StreetAddress $($user.StreetAddress) -State $($user.State) -City $($user.City) -OfficePhone $($user.OfficePhone)
}

Write-Host 'done!' -ForegroundColor Green