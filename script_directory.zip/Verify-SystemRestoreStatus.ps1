﻿function Verify-SystemRestoreStatus{
    [cmdletbinding()]
    param(
    )
    
    # Check if System Restore is Enabled
    # RPSessionInterval 1 = Enabled

    $RPSessionInterval = Get-WmiObject -Namespace 'root\default' -Class 'SystemRestoreConfig' | Select-Object -ExpandProperty RPSessionInterval

    if ($RPSessionInterval -eq 1){

        $boolCompRestoreEnabled = $True

        # Days Since Last Restore
        #If no restore points have been made, $listRestorePoints = $null
    }
    else{

        $boolCompRestoreEnabled = $false
    }

    # Output Props
    $restoreStatus = @{
        Enabled = $boolCompRestoreEnabled   
    }

    # Output Object
    New-Object -TypeName PSObject -Property $restoreStatus

    $restorestatus
}

Verify-SystemRestoreStatus