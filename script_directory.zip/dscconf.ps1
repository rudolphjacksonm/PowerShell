﻿Configuration BaseServerDSC {

    Node "S7CLMDT01" {
        WindowsFeature Powershell {
            Ensure = "Present"
            Name = "Powershell"
        }
        WindowsFeature .Net 3.5 {
            Ensure = "Present"
            Name = "NET-Framework-Features"
        }
    }
}