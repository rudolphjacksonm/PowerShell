﻿# Main Script Start
[CmdletBinding()]
param(
)

# Import Helper Functions
. .\helpers\Set-Hibernation.ps1

# Initiate LogStream
$global:LogStream = @()


try {
    $HibernationKeyValue = Get-Hibernation
    
    if ($HibernationKeyValue -eq 1) {
        $global:LogStream += "$(Get-Date), hibernation is currently enabled, key value: $HibernationKeyValue"

    }
    else {
        $global:LogStream += "$(Get-Date), hibernation is currently disabled, key value: $HibernationKeyValue"

    }
}
catch{
    $global:LogStream += "$(Get-Date), could not query hibernation settings."

}

$global:LogStream