﻿function Get-Krebs {
    [CmdletBinding()]

    param(
    )

    $htmlpage = (Invoke-WebRequest -Uri https://www.krebsonsecurity.com).RawContent
    foreach ($element in $htmlpage.getelementsbyclassname("post")) {
        $element.innertext
        $element
    }
}