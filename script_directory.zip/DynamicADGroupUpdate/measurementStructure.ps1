﻿#region Pre-Run Steps
# Init LogStream

$global:Logstream = @()


# Init ScriptRoot

$ScriptPath = $MyInvocation.MyCommand.Path
$global:ScriptRoot = Split-Path -Parent $ScriptPath
#endregion


 
#region Jack's Code [Appended 5/16/2016]

# Import AD Module
Import-Module ActiveDirectory

# Initiate Global variables
$global:SearchOU = 'OU=Users,OU=Gen II Fund Services\, LLC,DC=s7dev,DC=local'
$global:AllUsers = Get-ADUser -Filter * -Properties * -SearchBase $global:SearchOU

# Initiate LogStream
$global:LogStream = @()

# Import Helper functions
function Process-ADUserTitles {
    [CmdletBinding()]
    param
    (
        [Parameter(Mandatory = $true,
                   ValuefromPipelinebyPropertyName = $true,
                   Position = 0)]
        $SamAccountName,

        [Parameter(Mandatory = $false,
                   ValuefromPipelinebyPropertyName = $true,
                   Position = 1)]
        $title
    )

    process {
        
        switch ($title) {

            Director {
                
                # Verify user is not already member of group
                $GroupName = 'Directors'
                [bool]$VerifyMembership = Get-ADPrincipalGroupMembership -Identity $SamAccountName | Where-Object {$_.name -match $GroupName}

                if (!($VerifyMembership)) {
                    try {
                        Add-ADPrincipalGroupMembership -identity $SamAccountName -MemberOf $GroupName -ErrorAction Stop

                        # Log changes made to account
                        $global:LogStream += "$(Get-Date), added user $SamAccountName to AD Group: $GroupName"

                        $props = @{
                            'Username' = $SamAccountName
                            'Title' = $title
                            'GroupName' = 'Director'
                            'Action' = 'Added'
                        }
                    }
                    catch {
                        $global:LogStream += "$(Get-Date), could not add $SamAccountName to $GroupName, $_"

                    }
                }
                else {
                    # No changes need to be made.
                    # Logging
                    $global:LogStream += "$(Get-Date), user $SamAccountName already a member of AD Group: $GroupName"
                    $props = @{
                        'Username' = $SamAccountName
                        'Title' = $title
                        'GroupName' = 'Director'
                        'Action' = 'No Change'

                    }
                }   
            }
            
            "Managing Director" {

                # Verify user is not already member of group
                $GroupName = 'Managing Directors'
                [bool]$VerifyMembership = Get-ADPrincipalGroupMembership -Identity $SamAccountName | Where-Object {$_.name -match $GroupName}

                if (!($VerifyMembership)) {
                    try {
                        Add-ADPrincipalGroupMembership -identity $SamAccountName -MemberOf $GroupName -ErrorAction Stop

                        # Log changes made to account
                        $global:LogStream += "$(Get-Date), added user $SamAccountName to AD Group: $GroupName"

                        $props = @{
                            'Username' = $SamAccountName
                            'Title' = $title
                            'GroupName' = 'Managing Director'
                            'Action' = 'Added'
                        }
                    }
                    catch {
                        $global:LogStream += "$(Get-Date), could not add $SamAccountName to $GroupName, $_"

                    }
                }
                else {
                    # No changes need to be made.
                    # Logging
                    $global:LogStream += "$(Get-Date), user $SamAccountName already a member of AD Group: $GroupName"
                    $props = @{
                        'Username' = $SamAccountName
                        'Title' = $title
                        'GroupName' = 'Managing Director'
                        'Action' = 'No Change'

                    }
                }
            }
            
            default {
                $props = @{
                        'Username' = $SamAccountName
                        'Title' = $title
                        'Action' = 'No Change'
                }
            }
        }

        # Create object after running through switch block
        New-Object -TypeName PSObject -Property $props
    }
}


$syncactions = $global:AllUsers | Process-ADUserTitles
$global:LogStream

#endregion Jack's Code


#region Export Analysis to CSV
# Only attempt to export if we have syncActions

if($syncActions.count -gt 0){
    $date = Get-Date
    $reportDateTime = ((($date).GetDateTimeFormats())[3] -replace '/','_') + "_$($date.hour)"
    $syncActions | Export-Csv "$global:ScriptRoot\synchistory\syncHistory_$reportDateTime`.csv" -NoTypeInformation

}
#endregion


#region Wrap up/Send email if we have Sync Actions to report on

if(Test-Path "$global:ScriptRoot\synchistory\syncHistory_$reportDateTime`.csv"){
    # import smtpoptions
    . $global:ScriptRoot\helpers\SMTPOptions.ps1

    # build attachment array
    $attachmentArray = @()
    $attachmentArray += "C:\Scripts\SyncConfluenceAndNCentral\synchistory\syncHistory_$reportDateTime`.csv"


    # send email with report
    $smtpProps = @{
        'SmtpServer' = $global:smtpserver
        'To' = $global:emailalertTo
        'From' = $global:emailalertFrom
        'Subject' = $global:emailsubject
        'Attachments' = $attachmentArray
    }

    Send-MailMessage @smtpProps

}
#endregion