﻿# Main Script #

# Import AD Module
Import-Module ActiveDirectory

# Initiate Global variables
$global:SearchOU = 'OU=Users,OU=Gen II Fund Services\, LLC,DC=s7dev,DC=local'
$global:AllUsers = Get-ADUser -Filter * -Properties * -SearchBase $global:SearchOU

# Initiate LogStream
$global:LogStream = @()

# Import Helper functions
. .\helpers\Process-ADUserTitles.ps1


$syncactions = $global:AllUsers | Process-ADUserTitles
$global:LogStream