﻿Import-Module ActiveDirectory
$OrgUnit = Get-ADDomain | select computer*
Get-ADComputer -Filter * -SearchBase "$OrgUnit" | select name,distinguishedname,enabled | Export-Csv -NTI C:\Temp\adcomputers.csv