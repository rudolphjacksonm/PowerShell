﻿$startFolder = "C:\users\jmorris\pictures"
$finditems = (Get-ChildItem $startFolder | Measure-Object -Property length -Sum)
"C:\Users\jmorris\pictures -- " + "{0:N2}" -f ($finditems.sum / 1MB) + " MB"

$finditems = (Get-ChildItem $startFolder -recurse)
foreach ($item in $finditems)
{
 $subfolderItems = Get-ChildItem $i.FullName | Measure-Object -property length -sum
 $i.FullName + " -- " + "{0:N2}" -f ($subFolderItems.sum / 1MB) + " MB"
}