﻿function Remove-ActiveSyncPartnerships {
    [CmdletBinding()]
    param
    (
		# Identity of the mobile device
        [Parameter(Mandatory=$true,
                   ValuefromPipelinebyPropertyName=$true,
                   Position=0)]
        $Identity,

		# The friendly name of the device, e.g. 'Samsung G5'
        [Parameter(Mandatory=$true,
                   ValuefromPipelinebyPropertyName=$true,
                   Position=1)]
        $DeviceModel
    )

    # Remove ActiveSync devices received through pipeline
    begin {
    }
    process {
        try {
            Remove-ActiveSyncDevice -identity $Identity -Confirm:$False
                
            # Logging
            $global:LogStream += "$(Get-Date), removed device $DeviceModel"

	    }
	    catch {
		    $global:LogStream += "$(Get-Date), could not remove mobile device, $_"

        }
    }
    end {
    }
}